<?php

$arr = array('fff', 'ggg', '', '');
$arr = array_filter($arr);
print_r($arr);


